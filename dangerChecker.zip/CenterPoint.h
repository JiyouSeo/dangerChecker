struct CenterPoint
{
    double X;
    double Y;
};
